def test():
    print("This is a test function from example.py")
    return "Test completed successfully!"